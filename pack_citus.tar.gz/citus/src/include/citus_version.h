/* src/include/citus_version.h.  Generated from citus_version.h.in by configure.  */
/* This file is created manually */

/* Citus full name as a string */
#define CITUS_NAME "Citus"

/* Citus edition as a string */
#define CITUS_EDITION "community"

/* Extension version expected by this Citus build */
#define CITUS_EXTENSIONVERSION "7.3-1"

/* Citus major version as a string */
#define CITUS_MAJORVERSION "7.3"

/* Citus version as a string */
#define CITUS_VERSION "7.3devel"

/* Citus version as a number */
#define CITUS_VERSION_NUM 70300

/* A string containing the version number, platform, and C compiler */
#define CITUS_VERSION_STR "Citus 7.3devel on x86_64-pc-linux-gnu, compiled by gcc (Ubuntu 5.4.0-6ubuntu1~16.04.6) 5.4.0 20160609, 64-bit"

/* Define to 1 if you have the `curl' library (-lcurl). */
#define HAVE_LIBCURL 1

/* Base URL for statistics collection and update checks */
#define REPORTS_BASE_URL "https://reports.citusdata.com"
