/* citus--6.2-4--7.0-1.sql */

/* empty, but required to update the extension version */
