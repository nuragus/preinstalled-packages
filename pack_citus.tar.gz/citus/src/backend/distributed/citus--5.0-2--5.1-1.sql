/* citus--5.0-2--5.1-1.sql */

/* empty, but required to update the extension version */
