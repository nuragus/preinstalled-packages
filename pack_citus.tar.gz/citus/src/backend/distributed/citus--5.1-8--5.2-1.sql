/* citus--5.1-8--5.2-1.sql */

/* empty, but required to update the extension version */
